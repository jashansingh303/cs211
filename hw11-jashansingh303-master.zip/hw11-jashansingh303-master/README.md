# Homework 11 for Dr. Waxman's CS211 Fall 2020
[Requirement](https://venus.cs.qc.cuny.edu/~waxman/211/Rat%20class%20assignment.pdf)

## Name:  Jashandeep Singh

### How much time did it take you to complete this homework?
  2 hrs
  
### What challenges (if any) did you work through to finish this assignment?
creating operators

### Did you use any external resources? (Cite them below)
no
